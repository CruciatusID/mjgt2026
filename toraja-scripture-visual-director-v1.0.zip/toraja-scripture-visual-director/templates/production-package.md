# SELECTED CONCEPT — PRODUCTION PACKAGE

## Lock record
- Weekly date / exact Indonesian title:
- Selected concept / user approval:
- Source reading / goal:
- Visual thesis:
- Actors, props, architectural/historic environment:
- Locked foreground/midground/background and key lighting:
- Painterly style identity:

## 01 — 4:3 master artwork prompt
**Canvas:** 4:3, no typography, no signage, no watermark.
**Concept / camera / composition:** [fully specified]
**Exact negative-space safe zone for title:** [location & percentage]
**Subject placement and semantic elements:** [all inside 4:3 with inner margin]
**Light, palette, atmosphere:** [...]
**Handcrafted painterly 3D finish:** [...]
**Avoid:** split-screen, photoreal CGI, plastic shading, random glowing religious symbols, text, wrong era, cultural anachronism, malformed anatomy, generic fantasy.

## 02 — 16:9 outpainting prompt
**Input:** approved, final 4:3 artwork.
**Geometry:** center original in same-height 16:9; extend canvas left and right (each 12.5% final width). Retain master pixels wherever feasible.
**Allowed expansion:** [continuations of physical surfaces only]
**Locked:** original subject and silhouette, facial identities, light direction, brush texture, perspective, original title-safe empty area.
**Forbidden:** camera reframe, redraw, new essential objects, captions, wings with competing subjects, seams, texture mismatches.
**Crop-back check:** center 75% of final width must reproduce master and preserve original visual meaning.

## 03 — Separate Indonesian title graphic
- **Exact title text:** [verbatim]
- **Proposed line breaks:** [...]
- **Typography class and letter treatment:** [...]
- **Title color:** [...]
- **Background:** pure #000000 OR pure #FFFFFF; no gradients, no texture outside letters. Optional transparent PNG preferred.
- **Prompt for generator:** [exact printable wording, no extra text]
- **Alternative precise typesetting instructions:** [font class/weight/spacing, safe-zone max width, editable vector/PNG alpha]

## 04 — QA checklist
- [ ] Generated master reviewed: 4:3 scene fidelity and painterly texture
- [ ] Generated expanded 16:9 reviewed: crop-back, seamless continuity, no missing visual meaning
- [ ] Typography reviewed: exact spelling, alpha/background removal, tested over both frames
- [ ] No text in main images
- [ ] Cultural and biblical fidelity
State untested if images not supplied.
