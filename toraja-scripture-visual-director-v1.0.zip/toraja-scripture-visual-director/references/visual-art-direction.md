# Visual and cultural art direction

## Locked visual DNA
- Cinematic **painterly 3D** / hand-painted hybrid aesthetic: palpable broad/medium brush textures, matte gouache/oil-like surfaces, sculpted dimensional forms, restrained stylization, spatial depth, thoughtful palette, physical lighting, nuanced expressions and tactile clothing/foliage/architecture.
- The resulting image should feel like a carefully staged film still **painted by hand**, not a flat watercolor vignette, photo, illustration pasted on 3D, plastic CGI, Disney/Pixar look, anime, exaggerated character caricature, or rough accidental smear.
- Let mood serve the passage: hope warm; repentance contemplative; judgment reverent and weighty; thanksgiving luminous; suffering empathetic. No mandatory golden sunset or fog.
- Default art focus: one subject group, one physical moment, unified lighting and vanishing point, intentional silhouette/readability at screen distance.

## Toraja visual grammar
- Optional elements: authentic tongkonan architecture, Toraja rice terraces, steep lush mountains, wooded valleys, cloud and mist layers, villages, farming/family/ordinary communal life.
- Use only when narratively meaningful. If present, roof geometry, building construction and scale must resemble real tongkonan, not arbitrary East Asian roof ornaments.
- Contemporary human characters: natural Indonesian/Sulawesi faces and ordinary appropriate clothing; avoid generic Western stock-model features. Avoid costume stereotyping and ceremonial motifs when unjustified.
- Genuine Biblical scenes: period-appropriate Levant/Ancient Near East settings and ethnogeographic appearances; never present a Toraja adaptation as canonical historical Bible scene.
- A symbolic interpretation may omit people and culture altogether.

## Unified scene bans
Hard reject: side-by-side moral comparisons, good-vs-bad split panels, multiple horizons/angles, biblical montage, frame-in-frame, photo collage, before-after infographic, half-day half-night compositing, poster-layout boxes, floating objects unrelated spatially.
Allowed: subtle contrast *within one actual coherent environment*, only if the narrative naturally supports it and does not read as juxtaposed panels. Prefer choosing the core affirmative or challenging image rather than literalizing every opposite.

## Concept differentiation
Three proposals must have three materially distinct focal ideas, not just three camera angles/lighting changes on the same subject. Each must tell one idea cleanly; do not enforce a rigid 1-Biblical/1-Toraja/1-symbolic split.

## Suggested reusable style phrase
"Premium cinematic painterly 3D animated-film still; handcrafted painted textures with clearly visible expressive brushwork on every surface; convincing 3D volume and anatomy; matte material response; atmospheric depth; thoughtful cinematic lens and composition; emotionally intelligent natural light; sophisticated painterly color design; grounded and respectful biblical/church illustration; single cohesive scene."
