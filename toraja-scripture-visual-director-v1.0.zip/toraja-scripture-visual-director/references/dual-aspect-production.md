# 4:3 master → 16:9 extension specification

## Geometry
For identical heights H, 4:3 width W4=4H/3, 16:9 width W16=16H/9. Symmetric extension adds `(W16-W4)/2 = 2H/9` to **each** side. The 4:3 master occupies the **middle 75% of total 16:9 width** (since 4/3 divided by 16/9 = .75). Each expendable wing is 12.5% of final width. At 1152px high: master 1536×1152, final 2048×1152, +256px left and right.

## First image rules
- Compose master 4:3 as fully complete stand-alone frame, ideally leave title-negative-space *inside* 4:3. Title-safe area should be purpose-built (calm background, sufficient size/contrast), not empty white void by default.
- Make critical subject and gestures **interior to master** with margin; don't cut an essential face, object, or narrative gesture at master edge. Reserve default 5–8% inward safety from all edges for critical details (adjust explicitly if needed).
- Choose title on left/right/top based on scene, not automatically on left. Reserve enough negative space for the actual Indonesian title length. Do not put title in image itself.
- Ensure 4:3 alone still communicates theological thesis.

## Outpaint rules
- Preserve exact master content (original pixels where workflow permits), camera, lighting, brush texture, palette, geometry, and subject identities.
- Add only a physically continuous extension of horizon, clouds, foliage, wall, sky, farmland, vineyard, etc. **Do not add any meaningful person/object/symbol exclusive to wings**.
- Do not reframe, zoom, shift, or shrink the original 4:3 master. New framing is the master centrally embedded in 16:9.
- If model cannot pixel-lock, use masked outpainting and compare original region visually/pixel-wise where technically possible.
- Expansion can be asymmetric only if precisely defined as a crop rectangle and both final deliverables have been validated.

## QA
- Crop centered 16:9 to 4:3 (middle 75% width) and compare with original. Confirm main content, title safe zone, emotion and visual meaning all survive. If any loss, fail.
- Confirm no seam, repeated objects, inconsistent roof geometry, painterly texture mismatch, changed horizon/perspective, new disconnected narrative elements, or scale discontinuities.
- File or pixel dimensions may need minor rounding for actual generators; use precise ratio and nearest supported sizes. Never stretch the original.
