# Evaluation rubric and release gates

## Concept scoring (100 points)
- Faithfulness to supplied theme, readings & objectives: 35
- One clear coherent visual thesis (single scene; not a multi-panel comparison): 20
- Emotional/visual communication and screen-distance focal clarity: 15
- 4:3 integrity + negative space + 16:9 extension practicality: 15
- Correct Toraja/Biblical cultural and historical setting: 10
- Practical paintable painterly 3D direction: 5

Do not let score hide hard failures. **Hard fail** any: contradiction to supplied passage or aim; split-panel/comparison scene; essential object in expandable wing; title drawn into main image; gross cultural/historical confusion; malformed/anatomically disturbing human subjects; inappropriate religious imagery. Three concepts should be worth considering, with one recommended; revise weak ones instead of submitting three near-duplicates.

## Visual deliverable gates
1. Main 4:3 independently complete; focus and safe title area work at normal projector scale.
2. Expanded 16:9 centered 4:3 crop maintains content; no new substantive wing-only narrative or inconsistent details.
3. Painterly brushwork obvious and cohesive; realistic enough forms, not glossy or cartoonish.
4. People, hands, architecture, props, scenery appropriate to scene; scripture not misrepresented.
5. Separate Indonesian title exact and cleanly isolatable; tested over both crops.

Report three states accurately: **PASS / REVISE / NOT TESTED**. Prompts alone = NOT TESTED for generated-image tests. Never certify visual rendering you have not inspected.
