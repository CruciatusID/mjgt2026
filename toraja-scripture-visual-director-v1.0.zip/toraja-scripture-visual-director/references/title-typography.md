# Indonesian title artwork — independent asset

## Intent
Title is NOT part of main illustration. It is generated/rendered after chosen concept and follows illustration palette, emotional tone, and available space. User will place manually over 4:3 and 16:9.

## Fidelity
- Use **exact Indonesian theme title** verbatim from MD; do not translate, paraphrase or append scripture references. Toraja-language title is preserved in analysis but excluded unless requested.
- Determine line breaks by phrase semantics and safe-zone shape; prioritize legibility on distant church screens, contrast, clear negative space, distinctive but not ornate fonts.
- Choose one cinematic typography family for church identity, flex weight and accent by mood. Examples: elegant classic serif, restrained monumental serif, warm humanist serif; mention available real font choices only if verified on production machine. Use legal installed fonts.
- 3D/painterly treatment is **subtle**: handcrafted letterpress-like matte finish, delicate painted edge, light bevel only when beneficial; avoid illegible distress, extreme gradients, bulky extrusions, superfluous flourishes, religious clipart or exaggerated magical glow.

## Extraction options
1. **Preferred:** real-font/vector typography exported as transparent PNG/SVG, e.g. made in editor; exact spelling guaranteed. Provide production typography spec even if user opts for image generator.
2. If image generator: exact title on a **uniform pure black #000000 or pure white #FFFFFF** background with no gradient, texture, shadow or extra decorative objects *outside glyphs*. Choose title color high-contrast vs background. Optionally provide separate alpha asset when supported.
3. Keep shadow/glow minimal and tight to glyphs, never contaminate uniform background in a way that makes removal difficult.

## Prompt template variables
TITLE_EXACT; LINE_BREAKS; COLOR_PALETTE; TYPOGRAPHIC_CLASS; MOOD; BACKGROUND (#000000 / #FFFFFF); TYPE_TREATMENT; TEXT_ORIENTATION (horizontal); WIDTH_RELATIVE_TO_MASTER_SAFE_ZONE.

## QA
Verify every Indonesian letter, capitalization, spacing, punctuation, word sequence, line breaks, clipping and readability; text image models may fail exact orthography. If failure, switch to font/vector typography rather than repeated uncontrolled regeneration. Test compositing over BOTH 4:3 and 16:9 at realistic slide viewing size. Logo and watermark absent.
